/**
 * UI模块
 */
class UIModule extends egret.EventDispatcher implements IModule
{
    /**
     * 单例
     */
    private static _instance : UIModule = null;

    /**
     * 构造函数
     */
    public constructor()
    {
        super();

        UIModule._instance = this;

    }

    /**
     * 析构函数
     */
    public Dispose() : void
    {
        //单例
        UIModule._instance = null;
    }

    /**
     * 初始化
     * @param stage 舞台对象
     */
    public Initialize(stage : egret.Stage) : void
    {
        if (this._layerCenter)
        {
            this._layerCenter.Initialize(stage);
        }
    }

    /**
     * 反初始化
     */
    public Uninitialize() : void
    {
        if (this._layerCenter)
        {
            this._layerCenter.Uninitialize();
        }
    }

    /**
     * 部署层
     * @param layerArray 层数组
     */
    public static AssembleLayer(layerArray : Array<string>) : void
    {
        if (UIModule._instance &&
            UIModule._instance._layerCenter)
        {
            UIModule._instance._layerCenter.Assemble(layerArray);
        }
    }

    /**
     * 将UI添加到指定名字的层上
     * @param ui UI对象
     * @param layerName 层名字
     */
    public static AddUIToLayer(ui : UIable, layerName : string) : void
    {
        if (UIModule._instance &&
            UIModule._instance._layerCenter)
        {
            UIModule._instance._layerCenter.AddUIToLayer(ui, layerName);
        }
    }

    /**
     * 从指定名字的层上移除UI
     * @param ui UI对象
     * @param layerName 层名字
     */
    public static RemoveUIFromLayer(ui : UIable, layerName : string) : void
    {
        if (UIModule._instance &&
            UIModule._instance._layerCenter)
        {
            UIModule._instance._layerCenter.RemoveUIFromLayer(ui, layerName);
        }
    }
}

