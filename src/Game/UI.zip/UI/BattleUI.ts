class BattleUI implements IDisposable
{
    public constructor()
    {

    }

    public Dispose(): void
    {
    }
}
